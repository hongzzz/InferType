int main()
{
	int a=33;
	int b=44;
	int sum=a+b;
	int subab=a-b;
	int subba=b-a;
	int uk=sum+subab;
	int mul=a*b;
	int divab=a/b;
	int divba=b/a;
	double divdou=a/b;
}
