void main()
{
	float x,y;
	x=111111.111;
	y=222222.222;
	printf("%f\n",x+y);
}
