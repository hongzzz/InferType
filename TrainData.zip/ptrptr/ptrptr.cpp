#include<stdio.h>

void main(){
	int k,*p,**pp;
	k=8;
	p=&k;
	pp=&p;
	printf("x=%d\n",**pp);//*pp=p,**pp=k=8
}