int main()
{  char AString[]="String";
   printf("%s,%s\n",(void *)AString,AString);
   return 0;
}
