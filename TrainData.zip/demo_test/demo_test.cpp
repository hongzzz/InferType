// demo_test.cpp : �������̨Ӧ�ó������ڵ㡣
#include <iostream>
using namespace std;

int add(int a,int b)
{
	int c=a+b;
	return c;
}

float add(float a,float b)
{
	float c=a+b;
	return c;
}

double add(double a,double b)
{
	double c=a+b;
	return c;
}

int main()
{
	int InterNum=add(1,2);
	float FloatNum=add(1.0,2.0);
	double DoubleNum=add(1.0,2.0);

	char* HelloWorld="Hello World!";
	char A='a';
	int *IntPointer=new int[10];
	for(int i=0;i<10;i++)
		IntPointer[i]=i;

	int IntArray[5];
	for(int i=0;i<5;i++)
	{
		IntArray[i]=i;
	}

	system("pause");
	return 0;
}